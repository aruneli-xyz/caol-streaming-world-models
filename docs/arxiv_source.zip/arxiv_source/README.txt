arXiv source bundle for
"Control-Aligned Onset Latency and Copy-on-Write Speculative Branching for Streaming World Models"
Arunkumar Eli, Vasu Sharma (2026)

Contents
  master.tex               main document (non-anonymous preprint)
  results.tex              numeric macros, \input by master.tex
  figures/                 only the five figures master.tex includes
  anc/data/cow_microbench.json   arXiv ancillary file (not needed to compile)

Compile: pdflatex master.tex (twice). No bibtex step; the bibliography is inline.
Upload to arXiv or Overleaf as-is, keeping this directory structure.
Source of truth: https://github.com/arun-elr/caol-streaming-world-models (docs/)
